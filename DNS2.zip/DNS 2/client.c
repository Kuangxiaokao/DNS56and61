#include <stdio.h>
#include <string.h>
#include <stdlib.h>  
#include <unistd.h>  
#include <sys/stat.h>  
#include <fcntl.h>  
#include <errno.h>  
#include <netdb.h>  
#include <sys/types.h>  
#include <sys/socket.h>  
#include <netinet/in.h>  
#include <arpa/inet.h>
#include <stdint.h>

#define QUERRY_PORT 4096  
#define LOCAL_SERVER_IP "127.0.0.2" 
#define LOCAL_SERVER_PORT 53
#define ROOT_SERVER_IP "127.0.0.3"
#define ROOT_SERVER_PORT 53
#define COMMON_SERVER_PORT 53

#define MAX_SIZE_OF_DOMAIN 100

char value[MAX_SIZE_OF_DOMAIN];
typedef struct DNS_Header
{
	unsigned short id; 
	unsigned short tag;
	unsigned short queryNum;
	unsigned short answerNum;
	unsigned short authorNum;
	unsigned short addNum;
}DH;

typedef struct DNS_Query
{
	char *name; 
	unsigned short qtype;
	unsigned short qclass;
}DQ;

typedef struct DNS_RR  
{
	char *name;   
	unsigned short type;
	unsigned short _class;
	unsigned int ttl;
	unsigned short data_len;
	unsigned short pre;
	char *rdata;
}DR;

typedef struct tag
{
	unsigned short qr;
	unsigned short opcode;
	unsigned short aa;
	unsigned short tc;
	unsigned short rd;
	unsigned short ra;
	unsigned short z; 
	unsigned short rcode;
}TAG;


void put8bits(char *buffer,int *bufferPointer, char value)
{
	value = htons(value);
	memcpy(buffer + *bufferPointer,&value,1);
	*bufferPointer += 1;	
}
void put16bits(char *buffer,int *bufferPointer, unsigned short value)
{
	value = htons(value);
	memcpy(buffer + *bufferPointer,&value,2);
	*bufferPointer += 2;	
}
void put32bits(char *buffer,int *bufferPointer, unsigned int value)
{
	value = htons(value);
	memcpy(buffer + *bufferPointer,&value,4);
	*bufferPointer += 4;	
}

void putDomainName(char *buffer,int *bufferPointer, char *str)
{
	memcpy(buffer + *bufferPointer,str,strlen(str)+1);
	*bufferPointer += strlen(str)+1;
}
unsigned short get16bits(char *buffer,int *bufferPointer)
{
	unsigned short value;
	memcpy(&value,buffer + *bufferPointer,2);
	*bufferPointer += 2;
	
	return ntohs(value);  
}
unsigned int get32bits(char *buffer,int *bufferPointer)
{
	unsigned int value;
	memcpy(&value,buffer + *bufferPointer,4);
	*bufferPointer += 4;
	
	return ntohs(value);  
}

void getDomainName(char *buffer,int *bufferPointer,int *lengthOfDomain)  
{   
	
	int valueWriting=0;
	while(buffer[*bufferPointer]!=0)  
	{        
		value[valueWriting] = buffer[*bufferPointer]; 
		valueWriting++;
		(*bufferPointer)++;
	}
	value[valueWriting] = 0;
	(*bufferPointer)++;
	*lengthOfDomain = valueWriting+1;

	
}

void encodeDomain(char* domain)           
{
	memset(value,0,MAX_SIZE_OF_DOMAIN);
	int valueWriting=0;
	char *p,*q;
	q = domain;
	p = q;
	char count = 0;
	while(1)   
	{
		if((*p=='.')||(*p==0))
		{
			*(value+valueWriting)=count;
			valueWriting += 1;
			memcpy(value+valueWriting,q,count);
			valueWriting += count; 
			
			count = 0;
			if (*p=='.')
			{
				q=p+1;
				p = q;
			}else break;
		}else
		{
			p++;
			count++;
		}
	}
}

void decodeDomain(char* domain)
{
	memset(value,0,MAX_SIZE_OF_DOMAIN);
	int valueWriting = 0;
	char *p = domain;  
	int count = *p;
	while(count!=0)
	{
		for(int i=0;i<count;i++)
		{
			p += 1;
			value[valueWriting] = *p;
			valueWriting++;
		}
		if (*(p+1)!=0) 
		{
			value[valueWriting] = '.';
			valueWriting++;
		}
		p += 1;
		count = *p;
	}
	value[valueWriting]=0;
}

void HZDomainTransform(wchar_t *res,char *domain)
{
	res = malloc(sizeof(MAX_SIZE_OF_DOMAIN));
	memset(res,0,MAX_SIZE_OF_DOMAIN);
	memcpy(res,domain,strlen(domain));	
}

unsigned short createTag(unsigned short qr,unsigned short opcode,unsigned short aa,unsigned short tc,unsigned short rd,unsigned short ra,unsigned short z,unsigned short rcode)
{
	unsigned short tag = 0;
	if (qr==1)  tag = tag | 0x8000;
	if (aa==1)  tag = tag | 0x0400;
	if (tc==1)  tag = tag | 0x0200;
	if (rd==1)  tag = tag | 0x0100;
	if (ra==1)  tag = tag | 0x0080;
	return tag;
}

unsigned short typeToNum(char* type)
{
	if (strcmp(type,"A")==0) return 0x0001;
	if (strcmp(type,"NS")==0) return 0x0002;
	if (strcmp(type,"CNAME")==0) return 0x0005;
	if (strcmp(type,"MX")==0) return 0x000F;
	return 0;
}
char* numToType(unsigned short num)
{
	if (num==0x0001) return "A";
	if (num==0x0002) return "NS";
	if (num==0x0005) return "CNAME";
	if (num==0x000F) return "MX";
	return "ERROR";
}

void create_query_header(struct DNS_Header *query_header,unsigned short id,unsigned short tag,unsigned short queryNum,unsigned short answerNum,unsigned short authorNum,unsigned short addNum)
{
	query_header->id = id;
	query_header->tag = tag;
	query_header->queryNum = queryNum;
	query_header->answerNum = answerNum;
	query_header->authorNum = authorNum;
	query_header->addNum = addNum;
}

void encode_header(struct DNS_Header *header,char *buffer,int *bufferPointer)
{
	put16bits(buffer,bufferPointer,header->id);
	put16bits(buffer,bufferPointer,header->tag);
	put16bits(buffer,bufferPointer,header->queryNum);
	put16bits(buffer,bufferPointer,header->answerNum);
	put16bits(buffer,bufferPointer,header->authorNum);
	put16bits(buffer,bufferPointer,header->addNum);
}
void decode_header(struct DNS_Header *header,char *buffer,int *bufferPointer)
{
	header->id=get16bits(buffer,bufferPointer);
	header->tag=get16bits(buffer,bufferPointer);
	header->queryNum=get16bits(buffer,bufferPointer);
	header->answerNum=get16bits(buffer,bufferPointer);
	header->authorNum=get16bits(buffer,bufferPointer);
	header->addNum=get16bits(buffer,bufferPointer);
}
void print_query_header(struct DNS_Header *query_header)
{
	printf("information of dns header:\n");
	printf("ID:%d\n",query_header->id);
	printf("TAG:0x%x\n",query_header->tag);
	printf("Query Number:%d\n",query_header->queryNum);
	printf("Answer Number:%d\n",query_header->answerNum);
	printf("Authority Number:%d\n",query_header->authorNum);
	printf("Additional Number:%d\n",query_header->addNum);
	printf("\n");
}

void create_query_section(struct DNS_Query *query_section,char* domain_name, unsigned short qtype, unsigned short qclass)
{
	int domain_length = strlen(domain_name);
	query_section->name = malloc(domain_length+1);
	memcpy(query_section->name,domain_name,domain_length+1);	
	
	query_section->qtype = qtype;
	query_section->qclass = qclass;	
}

void encode_query_section(struct DNS_Query *query_section,char *buffer,int *bufferPointer)
{

	char *domain_name;
	int lengthOfEncodedDomain = strlen(query_section->name)+2;
	domain_name = malloc(lengthOfEncodedDomain);
	encodeDomain(query_section->name);
	memcpy(domain_name,value,lengthOfEncodedDomain);
	putDomainName(buffer,bufferPointer,domain_name); 
	
	put16bits(buffer,bufferPointer,query_section->qtype);
	put16bits(buffer,bufferPointer,query_section->qclass);
}

void decode_query_section(struct DNS_Query *query_section,char *buffer,int *bufferPointer)
{
	char* domain_name = malloc(MAX_SIZE_OF_DOMAIN); 
	memset(domain_name,0,MAX_SIZE_OF_DOMAIN);
	int lengthOfDomain=0;
	getDomainName(buffer,bufferPointer,&lengthOfDomain);
	memcpy(domain_name,value,lengthOfDomain);
	
	decodeDomain(domain_name);
	memcpy(domain_name,value,strlen(domain_name));  
	
	query_section->name = domain_name;
	query_section->qtype = get16bits(buffer,bufferPointer);
	query_section->qclass = get16bits(buffer,bufferPointer);
}

void print_query_section(struct DNS_Query *query_section)
{
	printf("information of query section:\n");
	printf("Name:[%s]\n",query_section->name);
	printf("Type:[%s]\n",numToType(query_section->qtype));
	printf("Class:[IN]\n");
	printf("\n");
}

void create_resource_record(struct DNS_RR *resource_record,char* name, unsigned short type, unsigned short _class, unsigned int ttl, unsigned short pre,char *rdata) //data_len不用输入  
{
	int domain_length = strlen(name);
	resource_record->name = malloc(domain_length+1);   
	memcpy(resource_record->name,name,domain_length+1);
	
	resource_record->type = type;
	resource_record->_class = _class;
	resource_record->ttl = ttl;
	if (type==0x0001) resource_record->data_len=4;
		else resource_record->data_len = strlen(rdata) + 2;
	
	if (type==0x000F) {
		resource_record->pre = pre;
		resource_record->data_len += 2;
	}
	
	int rdata_length = strlen(rdata);
	resource_record->rdata = malloc(rdata_length+1);
	memcpy(resource_record->rdata,rdata,rdata_length+1);
}

void encode_resource_record(struct DNS_RR *resource_record,char *buffer,int *bufferPointer)
{
	char *domain_name;
	int lengthOfEncodedDomain = strlen(resource_record->name)+2;
	domain_name = malloc(lengthOfEncodedDomain);
	 
	encodeDomain(resource_record->name);
	memcpy(domain_name,value,lengthOfEncodedDomain);
	
	putDomainName(buffer,bufferPointer,domain_name); 
	
	put16bits(buffer,bufferPointer,resource_record->type);
	put16bits(buffer,bufferPointer,resource_record->_class);
	put32bits(buffer,bufferPointer,resource_record->ttl);
	put16bits(buffer,bufferPointer,resource_record->data_len);   
	if (resource_record->type==0x000F) 
		put16bits(buffer,bufferPointer,resource_record->pre);
		         
	if(resource_record->type == 0x0001)         
	{
		unsigned int rdata = inet_addr(resource_record->rdata);
		memcpy(buffer + *bufferPointer,&rdata,4);
		*bufferPointer += 4;
	
	}else{          
		char *rdata;
		int lengthOfEncodedDomain2 = strlen(resource_record->rdata)+2;
		rdata = malloc(lengthOfEncodedDomain2);
		encodeDomain(resource_record->rdata);
		memcpy(rdata,value,lengthOfEncodedDomain2);   
		putDomainName(buffer,bufferPointer,rdata); 
	}
}

void decode_resource_record(struct DNS_RR *resource_record,char *buffer,int *bufferPointer)
{
	char* domain_name = malloc(MAX_SIZE_OF_DOMAIN); 
	memset(domain_name,0,MAX_SIZE_OF_DOMAIN);
	int lengthOfDomain=0;
	getDomainName(buffer,bufferPointer,&lengthOfDomain);
	memcpy(domain_name,value,lengthOfDomain);
	decodeDomain(domain_name);
	memcpy(domain_name,value,strlen(domain_name));  
	resource_record->name = domain_name;
	
	resource_record->type = get16bits(buffer,bufferPointer);
	resource_record->_class = get16bits(buffer,bufferPointer);
	resource_record->ttl = get32bits(buffer,bufferPointer);   
	resource_record->data_len = get16bits(buffer,bufferPointer);
	if (resource_record->type==0x000F) 
			resource_record->pre = get16bits(buffer,bufferPointer);
	if(resource_record->type == 0x0001)   
	{
		unsigned int rdata;
		memcpy(&rdata,buffer + *bufferPointer,4);
		*bufferPointer += 4;
		
		struct in_addr in;
		memcpy(&in, &rdata, 4);  
		
		resource_record->rdata = malloc(MAX_SIZE_OF_DOMAIN);
		char *temp =  inet_ntoa(in);
		memcpy(resource_record->rdata,temp,strlen(temp)+1);
	}else{
		char* rdata = malloc(MAX_SIZE_OF_DOMAIN); 
		int lengthOfDomain2=0;
		getDomainName(buffer,bufferPointer,&lengthOfDomain2);
		memcpy(rdata,value,lengthOfDomain2);
		decodeDomain(rdata);
		memcpy(rdata,value,strlen(rdata));  
		resource_record->rdata = rdata;
	}
}

void print_resource_record(struct DNS_RR *resource_record)
{
	printf("information of dns rr\n");
	printf("name:[%s]\n",resource_record->name);
	printf("type:[%s]\n",numToType(resource_record->type));
	printf("class:[IN]\n");
	printf("ttl:%d\n",resource_record->ttl);
	printf("data length:%d\n",resource_record->data_len);
	if (resource_record->type==0x000F) 
		printf("prefix:0x%x\n",resource_record->pre);
	printf("ip/domain:[%s]\n",resource_record->rdata);
	printf("\n");
}

void cut(char** domainPointer)
{
	while(1)
	{
		(*domainPointer)++;
		if (**domainPointer=='.')
		{
			(*domainPointer)++;
			break;		
		}
		if (**domainPointer==0)
		{
			*domainPointer = NULL;
			break;
		}
	}
}

void addRRToCache(struct DNS_RR *resource_record, char* cacheFile)
{
	FILE *RR = fopen(cacheFile, "a+");
	fprintf(RR,"%s         ",resource_record->name);
	fprintf(RR,"%d         ",resource_record->ttl);
	fprintf(RR,"IN         ");
	fprintf(RR,"%s         ",numToType(resource_record->type));
	fprintf(RR,"%s\n",resource_record->rdata);
	fclose(RR);
}

int main(int argc, char *argv[]) 
{ 
	//容错
	if (typeToNum(argv[2])==0)
		{
			printf("Wrong input type\n");
			exit(0);
		}
	
	/*①连接本地服务器 初始化TCP连接*/
	//客户端socket套接字文件描述符
	int clientSocket = socket(AF_INET, SOCK_STREAM, 0);
	//发送缓冲和接收缓冲
	char sendbuf[512];    
	char recvbuf[512];
	//定义sendbuf指示下标
	int sendBufferPointer=0;
	int recvBufferPointer=0;
	//清空缓存
	memset(sendbuf,0,512);
	memset(recvbuf,0,512);
	
	//描述服务器的socket,填充sockaddr_in数据结构
	struct sockaddr_in serverAddr;
	serverAddr.sin_family = AF_INET;
	//htons()函数用于将主机端口号转化为网络字节序端口号
	serverAddr.sin_port = htons(LOCAL_SERVER_PORT);
	//inet_addr()函数用于将点十分进制IP转换为网络字节序IP
	serverAddr.sin_addr.s_addr = inet_addr(LOCAL_SERVER_IP);
	//连接服务器
	if(connect(clientSocket, (struct sockaddr *)&serverAddr, sizeof(serverAddr))==-1)
		printf("connection failed\n");
	
	/*②根据输入内容，填充结构体，准备DNS Packet，并写入缓冲区sendbuf*/
	//完成DNS Head
	//定义DNS头部结构体
	struct DNS_Header *query_header;
	query_header = malloc(sizeof(DH));
	//调用函数，填写欲发送的DNS包的头部结构体
	//对应: qr,opcode,aa,tc,rd,ra,z,rcode，其中opcode z rcode可以随便填写. 默认不超过512，tc为1
	unsigned short tag = createTag(0,0,0,0,0,0,0,0);    //生成头的数据在这里填写
	//对应：id, tag, queryNum, answerNum, authorNum, addNum      //argc-1除2即为域名请求的个数，因为每个域名参数后带一个类型
	create_query_header(query_header,0x1234,tag,1,0x0000,0x0000,0x0000);
	//调用encode_header函数，将头部写入缓冲区
	encode_header(query_header,sendbuf,&sendBufferPointer);
	print_query_header(query_header);
	
	//通过运行参数生成一个或多个query_section并写入缓冲区                         
	//完成DNS Query
	//argv[i]即为输入的域名,argc即为请求个数，直接使用 
	unsigned short qtype = typeToNum(argv[2]);    //argv[2*i]字符串对应的类型
	unsigned short qclass = 0x0001;   //资源记录类型一般为IN (0x0001)
		
	struct DNS_Query *query_section;
	query_section = malloc(sizeof(DQ));
	create_query_section(query_section,argv[1],qtype,qclass);
	encode_query_section(query_section,sendbuf,&sendBufferPointer);	
	print_query_section(query_section);

	/*③向本地服务器发送数据包*/
	//发送已准备好的在缓冲区的数据,包总长度即为当下发送缓冲区指针下标
	unsigned short length = htons(sendBufferPointer);
	//对于TCP（客户端-本地服务器），必须先发送一个DNS包总长度
	send(clientSocket,&length,2,0);
	send(clientSocket, sendbuf, sendBufferPointer, 0);
	//printf("length:%d\n",sendBufferPointer);
	
	/*④根据query数量收包,发送了多少个query就会收到多少个DNS PACKET*/
	for(int k=0;k<query_header->queryNum;k++)
	{
		//先接收一个length，代表包的长度
		unsigned short recv_length;
		recv(clientSocket,&recv_length,2,0);
		recv_length = ntohs(recv_length);
		int dataNum = recv(clientSocket, recvbuf, recv_length, 0);
	
		/*⑤处理接收到缓冲区的DNS PACKET,从中抽取出需要返还给用户的数据*/
		//构造DNS包头部，从缓冲区读取并填充DNS头部	
		struct DNS_Header *recv_header;
		recv_header = malloc(sizeof(DH));
		decode_header(recv_header,recvbuf,&recvBufferPointer);
		print_query_header(recv_header);	
		struct DNS_RR *recv_answer,*recv_add;
		for(int i=0;i<recv_header->answerNum;i++)
		{
			//读取解析打印一个answer部分
			recv_answer = NULL;
			recv_answer = malloc(sizeof(DR));
			decode_resource_record(recv_answer,recvbuf,&recvBufferPointer);
			print_resource_record(recv_answer);
		}
		for(int i=0;i<recv_header->addNum;i++)
		{
			//读取解析打印一个addition部分
			recv_add = NULL;
			recv_add = malloc(sizeof(DQ));
			decode_resource_record(recv_add,recvbuf,&recvBufferPointer);
			print_resource_record(recv_add);
		}
		recvBufferPointer=0;
		memset(recvbuf,0,512);	
	}
	close(clientSocket);
}