#include <stdio.h>
#include <string.h>
#include <stdlib.h>  
#include <unistd.h>  
#include <sys/stat.h>  
#include <fcntl.h>  
#include <errno.h>  
#include <netdb.h>  
#include <sys/types.h>  
#include <sys/socket.h>  
#include <netinet/in.h>  
#include <arpa/inet.h>

#define SERVER_IP "127.0.0.7"
#define QUERRY_PORT 4096  
#define LOCAL_SERVER_IP "127.0.0.2" 
#define LOCAL_SERVER_PORT 53
#define ROOT_SERVER_IP "127.0.0.3"
#define ROOT_SERVER_PORT 53
#define COMMON_SERVER_PORT 53

#define MAX_SIZE_OF_DOMAIN 100

char value[MAX_SIZE_OF_DOMAIN];
typedef struct DNS_Header
{
	unsigned short id; 
	unsigned short tag;
	unsigned short queryNum;
	unsigned short answerNum;
	unsigned short authorNum;
	unsigned short addNum;
}DH;

typedef struct DNS_Query
{
	char *name; 
	unsigned short qtype;
	unsigned short qclass;
}DQ;

typedef struct DNS_RR  
{
	char *name;   
	unsigned short type;
	unsigned short _class;
	unsigned int ttl;
	unsigned short data_len;
	unsigned short pre;
	char *rdata;
}DR;

typedef struct tag
{
	unsigned short qr;
	unsigned short opcode;
	unsigned short aa;
	unsigned short tc;
	unsigned short rd;
	unsigned short ra;
	unsigned short z; 
	unsigned short rcode;
}TAG;


void put8bits(char *buffer,int *bufferPointer, char value)
{
	value = htons(value);
	memcpy(buffer + *bufferPointer,&value,1);
	*bufferPointer += 1;	
}
void put16bits(char *buffer,int *bufferPointer, unsigned short value)
{
	value = htons(value);
	memcpy(buffer + *bufferPointer,&value,2);
	*bufferPointer += 2;	
}
void put32bits(char *buffer,int *bufferPointer, unsigned int value)
{
	value = htons(value);
	memcpy(buffer + *bufferPointer,&value,4);
	*bufferPointer += 4;	
}

void putDomainName(char *buffer,int *bufferPointer, char *str)
{
	memcpy(buffer + *bufferPointer,str,strlen(str)+1);
	*bufferPointer += strlen(str)+1;
}
unsigned short get16bits(char *buffer,int *bufferPointer)
{
	unsigned short value;
	memcpy(&value,buffer + *bufferPointer,2);
	*bufferPointer += 2;
	
	return ntohs(value);  
}
unsigned int get32bits(char *buffer,int *bufferPointer)
{
	unsigned int value;
	memcpy(&value,buffer + *bufferPointer,4);
	*bufferPointer += 4;
	
	return ntohs(value);  
}

void getDomainName(char *buffer,int *bufferPointer,int *lengthOfDomain)  
{   
	
	int valueWriting=0;
	while(buffer[*bufferPointer]!=0)  
	{        
		value[valueWriting] = buffer[*bufferPointer]; 
		valueWriting++;
		(*bufferPointer)++;
	}
	value[valueWriting] = 0;
	(*bufferPointer)++;
	*lengthOfDomain = valueWriting+1;

	
}

void encodeDomain(char* domain)           
{
	memset(value,0,MAX_SIZE_OF_DOMAIN);
	int valueWriting=0;
	char *p,*q;
	q = domain;
	p = q;
	char count = 0;
	while(1)   
	{
		if((*p=='.')||(*p==0))
		{
			*(value+valueWriting)=count;
			valueWriting += 1;
			memcpy(value+valueWriting,q,count);
			valueWriting += count; 
			
			count = 0;
			if (*p=='.')
			{
				q=p+1;
				p = q;
			}else break;
		}else
		{
			p++;
			count++;
		}
	}
}

void decodeDomain(char* domain)
{
	memset(value,0,MAX_SIZE_OF_DOMAIN);
	int valueWriting = 0;
	char *p = domain;  
	int count = *p;
	while(count!=0)
	{
		for(int i=0;i<count;i++)
		{
			p += 1;
			value[valueWriting] = *p;
			valueWriting++;
		}
		if (*(p+1)!=0) 
		{
			value[valueWriting] = '.';
			valueWriting++;
		}
		p += 1;
		count = *p;
	}
	value[valueWriting]=0;
}

void HZDomainTransform(wchar_t *res,char *domain)
{
	res = malloc(sizeof(MAX_SIZE_OF_DOMAIN));
	memset(res,0,MAX_SIZE_OF_DOMAIN);
	memcpy(res,domain,strlen(domain));	
}

unsigned short createTag(unsigned short qr,unsigned short opcode,unsigned short aa,unsigned short tc,unsigned short rd,unsigned short ra,unsigned short z,unsigned short rcode)
{
	unsigned short tag = 0;
	if (qr==1)  tag = tag | 0x8000;
	if (aa==1)  tag = tag | 0x0400;
	if (tc==1)  tag = tag | 0x0200;
	if (rd==1)  tag = tag | 0x0100;
	if (ra==1)  tag = tag | 0x0080;
	return tag;
}

unsigned short typeToNum(char* type)
{
	if (strcmp(type,"A")==0) return 0x0001;
	if (strcmp(type,"NS")==0) return 0x0002;
	if (strcmp(type,"CNAME")==0) return 0x0005;
	if (strcmp(type,"MX")==0) return 0x000F;
	return 0;
}
char* numToType(unsigned short num)
{
	if (num==0x0001) return "A";
	if (num==0x0002) return "NS";
	if (num==0x0005) return "CNAME";
	if (num==0x000F) return "MX";
	return "ERROR";
}

void create_query_header(struct DNS_Header *query_header,unsigned short id,unsigned short tag,unsigned short queryNum,unsigned short answerNum,unsigned short authorNum,unsigned short addNum)
{
	query_header->id = id;
	query_header->tag = tag;
	query_header->queryNum = queryNum;
	query_header->answerNum = answerNum;
	query_header->authorNum = authorNum;
	query_header->addNum = addNum;
}

void encode_header(struct DNS_Header *header,char *buffer,int *bufferPointer)
{
	put16bits(buffer,bufferPointer,header->id);
	put16bits(buffer,bufferPointer,header->tag);
	put16bits(buffer,bufferPointer,header->queryNum);
	put16bits(buffer,bufferPointer,header->answerNum);
	put16bits(buffer,bufferPointer,header->authorNum);
	put16bits(buffer,bufferPointer,header->addNum);
}
void decode_header(struct DNS_Header *header,char *buffer,int *bufferPointer)
{
	header->id=get16bits(buffer,bufferPointer);
	header->tag=get16bits(buffer,bufferPointer);
	header->queryNum=get16bits(buffer,bufferPointer);
	header->answerNum=get16bits(buffer,bufferPointer);
	header->authorNum=get16bits(buffer,bufferPointer);
	header->addNum=get16bits(buffer,bufferPointer);
}
void print_query_header(struct DNS_Header *query_header)
{
	printf("information of dns header:\n");
	printf("ID:%d\n",query_header->id);
	printf("TAG:0x%x\n",query_header->tag);
	printf("Query Number:%d\n",query_header->queryNum);
	printf("Answer Number:%d\n",query_header->answerNum);
	printf("Authority Number:%d\n",query_header->authorNum);
	printf("Additional Number:%d\n",query_header->addNum);
	printf("\n");
}

void create_query_section(struct DNS_Query *query_section,char* domain_name, unsigned short qtype, unsigned short qclass)
{
	int domain_length = strlen(domain_name);
	query_section->name = malloc(domain_length+1);
	memcpy(query_section->name,domain_name,domain_length+1);	
	
	query_section->qtype = qtype;
	query_section->qclass = qclass;	
}

void encode_query_section(struct DNS_Query *query_section,char *buffer,int *bufferPointer)
{

	char *domain_name;
	int lengthOfEncodedDomain = strlen(query_section->name)+2;
	domain_name = malloc(lengthOfEncodedDomain);
	encodeDomain(query_section->name);
	memcpy(domain_name,value,lengthOfEncodedDomain);
	putDomainName(buffer,bufferPointer,domain_name); 
	
	put16bits(buffer,bufferPointer,query_section->qtype);
	put16bits(buffer,bufferPointer,query_section->qclass);
}

void decode_query_section(struct DNS_Query *query_section,char *buffer,int *bufferPointer)
{
	char* domain_name = malloc(MAX_SIZE_OF_DOMAIN); 
	memset(domain_name,0,MAX_SIZE_OF_DOMAIN);
	int lengthOfDomain=0;
	getDomainName(buffer,bufferPointer,&lengthOfDomain);
	memcpy(domain_name,value,lengthOfDomain);
	
	decodeDomain(domain_name);
	memcpy(domain_name,value,strlen(domain_name));  
	
	query_section->name = domain_name;
	query_section->qtype = get16bits(buffer,bufferPointer);
	query_section->qclass = get16bits(buffer,bufferPointer);
}

void print_query_section(struct DNS_Query *query_section)
{
	printf("information of query section:\n");
	printf("Name:[%s]\n",query_section->name);
	printf("Type:[%s]\n",numToType(query_section->qtype));
	printf("Class:[IN]\n");
	printf("\n");
}

void create_resource_record(struct DNS_RR *resource_record,char* name, unsigned short type, unsigned short _class, unsigned int ttl, unsigned short pre,char *rdata) //data_len不用输入  
{
	int domain_length = strlen(name);
	resource_record->name = malloc(domain_length+1);   
	memcpy(resource_record->name,name,domain_length+1);
	
	resource_record->type = type;
	resource_record->_class = _class;
	resource_record->ttl = ttl;
	if (type==0x0001) resource_record->data_len=4;
		else resource_record->data_len = strlen(rdata) + 2;
	
	if (type==0x000F) {
		resource_record->pre = pre;
		resource_record->data_len += 2;
	}
	
	int rdata_length = strlen(rdata);
	resource_record->rdata = malloc(rdata_length+1);
	memcpy(resource_record->rdata,rdata,rdata_length+1);
}

void encode_resource_record(struct DNS_RR *resource_record,char *buffer,int *bufferPointer)
{
	char *domain_name;
	int lengthOfEncodedDomain = strlen(resource_record->name)+2;
	domain_name = malloc(lengthOfEncodedDomain);
	 
	encodeDomain(resource_record->name);
	memcpy(domain_name,value,lengthOfEncodedDomain);
	
	putDomainName(buffer,bufferPointer,domain_name); 
	
	put16bits(buffer,bufferPointer,resource_record->type);
	put16bits(buffer,bufferPointer,resource_record->_class);
	put32bits(buffer,bufferPointer,resource_record->ttl);
	put16bits(buffer,bufferPointer,resource_record->data_len);   
	if (resource_record->type==0x000F) 
		put16bits(buffer,bufferPointer,resource_record->pre);
		         
	if(resource_record->type == 0x0001)         
	{
		unsigned int rdata = inet_addr(resource_record->rdata);
		memcpy(buffer + *bufferPointer,&rdata,4);
		*bufferPointer += 4;
	
	}else{          
		char *rdata;
		int lengthOfEncodedDomain2 = strlen(resource_record->rdata)+2;
		rdata = malloc(lengthOfEncodedDomain2);
		encodeDomain(resource_record->rdata);
		memcpy(rdata,value,lengthOfEncodedDomain2);   
		putDomainName(buffer,bufferPointer,rdata); 
	}
}

void decode_resource_record(struct DNS_RR *resource_record,char *buffer,int *bufferPointer)
{
	char* domain_name = malloc(MAX_SIZE_OF_DOMAIN); 
	memset(domain_name,0,MAX_SIZE_OF_DOMAIN);
	int lengthOfDomain=0;
	getDomainName(buffer,bufferPointer,&lengthOfDomain);
	memcpy(domain_name,value,lengthOfDomain);
	decodeDomain(domain_name);
	memcpy(domain_name,value,strlen(domain_name));  
	resource_record->name = domain_name;
	
	resource_record->type = get16bits(buffer,bufferPointer);
	resource_record->_class = get16bits(buffer,bufferPointer);
	resource_record->ttl = get32bits(buffer,bufferPointer);   
	resource_record->data_len = get16bits(buffer,bufferPointer);
	if (resource_record->type==0x000F) 
			resource_record->pre = get16bits(buffer,bufferPointer);
	if(resource_record->type == 0x0001)   
	{
		unsigned int rdata;
		memcpy(&rdata,buffer + *bufferPointer,4);
		*bufferPointer += 4;
		
		struct in_addr in;
		memcpy(&in, &rdata, 4);  
		
		resource_record->rdata = malloc(MAX_SIZE_OF_DOMAIN);
		char *temp =  inet_ntoa(in);
		memcpy(resource_record->rdata,temp,strlen(temp)+1);
	}else{
		char* rdata = malloc(MAX_SIZE_OF_DOMAIN); 
		int lengthOfDomain2=0;
		getDomainName(buffer,bufferPointer,&lengthOfDomain2);
		memcpy(rdata,value,lengthOfDomain2);
		decodeDomain(rdata);
		memcpy(rdata,value,strlen(rdata));  
		resource_record->rdata = rdata;
	}
}

void print_resource_record(struct DNS_RR *resource_record)
{
	printf("information of dns rr\n");
	printf("name:[%s]\n",resource_record->name);
	printf("type:[%s]\n",numToType(resource_record->type));
	printf("class:[IN]\n");
	printf("ttl:%d\n",resource_record->ttl);
	printf("data length:%d\n",resource_record->data_len);
	if (resource_record->type==0x000F) 
		printf("prefix:0x%x\n",resource_record->pre);
	printf("ip/domain:[%s]\n",resource_record->rdata);
	printf("\n");
}

void cut(char** domainPointer)
{
	while(1)
	{
		(*domainPointer)++;
		if (**domainPointer=='.')
		{
			(*domainPointer)++;
			break;		
		}
		if (**domainPointer==0)
		{
			*domainPointer = NULL;
			break;
		}
	}
}

void addRRToCache(struct DNS_RR *resource_record, char* cacheFile)
{
	FILE *RR = fopen(cacheFile, "a+");
	fprintf(RR,"%s         ",resource_record->name);
	fprintf(RR,"%d         ",resource_record->ttl);
	fprintf(RR,"IN         ");
	fprintf(RR,"%s         ",numToType(resource_record->type));
	fprintf(RR,"%s\n",resource_record->rdata);
	fclose(RR);
}

int main(int argc, char *argv[]) 
{
	char sendbuf[512];
	char recvbuf[512]; 
	int sendBufferPointer=0;
	int recvBufferPointer=0;
	memset(sendbuf,0,512);
	memset(recvbuf,0,512);
	
	int sockfd=socket(AF_INET,SOCK_DGRAM,0);
	struct sockaddr_in addr;
	addr.sin_family =AF_INET;
	addr.sin_port =htons(COMMON_SERVER_PORT);
	addr.sin_addr.s_addr=inet_addr(SERVER_IP);   
	
	bind(sockfd,(struct sockaddr*)&addr,sizeof(addr));
	struct sockaddr_in cli;
	socklen_t len=sizeof(cli);
	while(1)   
	{
		recvfrom(sockfd,recvbuf,sizeof(recvbuf),0,(struct sockaddr*)&cli,&len);
		//读取，构造包，得到需要找的域名和类型
		struct DNS_Header *recv_header;
		recv_header = malloc(sizeof(DH));
		decode_header(recv_header,recvbuf,&recvBufferPointer);
		print_query_header(recv_header);	
		
		struct DNS_Query *query_section;
		query_section = malloc(sizeof(DQ));
		decode_query_section(query_section,recvbuf,&recvBufferPointer);
		print_query_section(query_section);      
		
		//answer authoriy addition类型的RR各定义一个
		struct DNS_RR *send_answer,*send_authority,*send_additional;
		
		char *domain = query_section->name;  
		
		/*开始查找与写buffer过程，查找目标：query_section->name,query_section->qtype*/
		int over = 0;
		FILE *RR = fopen( "L4RR.txt", "a+" );
		fseek(RR,0,0);
		
		//定义一个RR结构体用来储存从文件中读入的一条RR
		struct DNS_RR *fileRR;
		fileRR = malloc(sizeof(DR));
		memset(fileRR,0,sizeof(DR));
		fileRR->name=malloc(MAX_SIZE_OF_DOMAIN);  
		fileRR->rdata=malloc(MAX_SIZE_OF_DOMAIN);
		//第一次搜索
		while(fscanf(RR,"%s ",fileRR->name)!=EOF)   
		{
			fscanf(RR,"%d",&fileRR->ttl);
			char type[10],_class[10];
			fscanf(RR,"%s ",_class);
			fscanf(RR,"%s ",type);
			fileRR->type = typeToNum(type);
			fscanf(RR,"%s\n",fileRR->rdata);
			
			if((strcmp(query_section->name,fileRR->name)==0) && (query_section->qtype==fileRR->type))
			{
				//生成answer RR
				create_resource_record(fileRR,fileRR->name, fileRR->type, 0x0001, fileRR->ttl, 0x0000,fileRR->rdata);
				//生成头
				struct DNS_Header *header;
				header = malloc(sizeof(DH));
				unsigned short tag = createTag(1,0,1,0,0,0,0,0);
				if (strcmp(type,"MX")==0)   create_query_header(header,0x1235,tag,0,1,0,1);
					else create_query_header(header,0x1235,tag,0,1,0,0);
				//将头和answer encode进buffer
				encode_header(header,sendbuf,&sendBufferPointer);
				print_query_header(header);
				encode_resource_record(fileRR,sendbuf,&sendBufferPointer);
				print_resource_record(fileRR);
				over=1;
				break;
			}
		}
		//一次搜索结束，此时已经读到文件末尾，需要把文件读写指针反饶回文件开始处
		fseek(RR,0,0);
		
		//对于MX类型，特殊，需要再搜索一遍，搜索到的邮件服务器域名的IP，并写入addition RR中发送    
		if (fileRR->type==0x000F) 
		{
			struct DNS_RR *addFileRR;
			addFileRR = malloc(sizeof(DR));
			addFileRR->name=malloc(MAX_SIZE_OF_DOMAIN);
			addFileRR->rdata=malloc(MAX_SIZE_OF_DOMAIN);
			while(fscanf(RR,"%s ",addFileRR->name)!=EOF)
			{
				fscanf(RR,"%d ",&addFileRR->ttl);
				char type[10],_class[10];
				fscanf(RR,"%s ",_class);
				fscanf(RR,"%s ",type);
				addFileRR->type = typeToNum(type);
				fscanf(RR,"%s\n",addFileRR->rdata);
				if(strcmp(fileRR->rdata,addFileRR->name)==0)
				{
					//生成addition RR
					create_resource_record(addFileRR,fileRR->rdata, 1, 1, fileRR->ttl, 0, addFileRR->rdata);
					encode_resource_record(addFileRR,sendbuf,&sendBufferPointer);
					print_resource_record(addFileRR);
					break;
				}
			}	
		}
		
		cut(&query_section->name);
		//剪掉首段地址，进行第二次搜索
		while(query_section->name!=NULL)
		{
			fseek(RR,0,0);  
			
			struct DNS_RR *nextRR;
			nextRR = malloc(sizeof(DR));
			nextRR->name=malloc(MAX_SIZE_OF_DOMAIN);
			nextRR->rdata=malloc(MAX_SIZE_OF_DOMAIN);
			while(fscanf(RR,"%s ",nextRR->name)!=EOF)
			{
				fscanf(RR,"%d ",&nextRR->ttl);
				char type[10],_class[10];
				fscanf(RR,"%s ",_class);
				fscanf(RR,"%s ",type);
				nextRR->type = typeToNum(type);
				fscanf(RR,"%s\n",nextRR->rdata);
				if(strcmp(query_section->name,nextRR->name)==0)
				{
					struct DNS_Header *header;
					header = malloc(sizeof(DH));
					unsigned short tag = createTag(1,0,1,0,0,0,0,0);
					create_query_header(header,0x1235,tag,0,0,1,1);
					encode_header(header,sendbuf,&sendBufferPointer);
					print_query_header(header);
					
					//生成authority RR  NS记录type=2   此时query_section->name经过cut后已经变成了下一个要去的DNS服务器域名
					struct DNS_RR *authRR;
					authRR = malloc(sizeof(DR));
					create_resource_record(authRR, domain, 2, 1, fileRR->ttl, 0, query_section->name);
					encode_resource_record(authRR,sendbuf,&sendBufferPointer);
					print_resource_record(authRR);
					
					//生成additon RR   A记录type=1
					struct DNS_RR *addRR;
					addRR = malloc(sizeof(DR));
					create_resource_record(addRR, domain, 1, 1, fileRR->ttl, 0, nextRR->rdata);
					encode_resource_record(addRR,sendbuf,&sendBufferPointer);
					print_resource_record(addRR);
					
					goto out;
				}
			}	
			cut(&query_section->name);	
		}
		out:
		fclose(RR);
		
		//发送
		sendto(sockfd,sendbuf,sendBufferPointer,0,(struct sockaddr*)&cli,len);  
		//缓冲区重置
		sendBufferPointer=0;    
		//这里千万别写成int sendBufferPointer，否则就是新建的一个局部变量!而不是程序开头的全局变量！
		recvBufferPointer=0;
		memset(sendbuf,0,512);
		memset(recvbuf,0,512);
	}
	close(sockfd); //sockfd定义的是服务端的套接字。只有在本服务器关闭的时候才会关闭sockfd
}