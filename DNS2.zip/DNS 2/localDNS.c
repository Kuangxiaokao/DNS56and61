#include <stdio.h>
#include <string.h>
#include <stdlib.h>  
#include <unistd.h>  
#include <sys/stat.h>  
#include <fcntl.h>  
#include <errno.h>  
#include <netdb.h>  
#include <sys/types.h>  
#include <sys/socket.h>  
#include <netinet/in.h>  
#include <arpa/inet.h>

#define QUERRY_PORT 4096  
#define LOCAL_SERVER_IP "127.0.0.2" 
#define LOCAL_SERVER_PORT 53
#define ROOT_SERVER_IP "127.0.0.3"
#define ROOT_SERVER_PORT 53
#define COMMON_SERVER_PORT 53

#define MAX_SIZE_OF_DOMAIN 100

char value[MAX_SIZE_OF_DOMAIN];
typedef struct DNS_Header
{
	unsigned short id; 
	unsigned short tag;
	unsigned short queryNum;
	unsigned short answerNum;
	unsigned short authorNum;
	unsigned short addNum;
}DH;

typedef struct DNS_Query
{
	char *name; 
	unsigned short qtype;
	unsigned short qclass;
}DQ;

typedef struct DNS_RR  
{
	char *name;   
	unsigned short type;
	unsigned short _class;
	unsigned int ttl;
	unsigned short data_len;
	unsigned short pre;
	char *rdata;
}DR;

typedef struct tag
{
	unsigned short qr;
	unsigned short opcode;
	unsigned short aa;
	unsigned short tc;
	unsigned short rd;
	unsigned short ra;
	unsigned short z; 
	unsigned short rcode;
}TAG;


void put8bits(char *buffer,int *bufferPointer, char value)
{
	value = htons(value);
	memcpy(buffer + *bufferPointer,&value,1);
	*bufferPointer += 1;	
}
void put16bits(char *buffer,int *bufferPointer, unsigned short value)
{
	value = htons(value);
	memcpy(buffer + *bufferPointer,&value,2);
	*bufferPointer += 2;	
}
void put32bits(char *buffer,int *bufferPointer, unsigned int value)
{
	value = htons(value);
	memcpy(buffer + *bufferPointer,&value,4);
	*bufferPointer += 4;	
}

void putDomainName(char *buffer,int *bufferPointer, char *str)
{
	memcpy(buffer + *bufferPointer,str,strlen(str)+1);
	*bufferPointer += strlen(str)+1;
}
unsigned short get16bits(char *buffer,int *bufferPointer)
{
	unsigned short value;
	memcpy(&value,buffer + *bufferPointer,2);
	*bufferPointer += 2;
	
	return ntohs(value);  
}
unsigned int get32bits(char *buffer,int *bufferPointer)
{
	unsigned int value;
	memcpy(&value,buffer + *bufferPointer,4);
	*bufferPointer += 4;
	
	return ntohs(value);  
}

void getDomainName(char *buffer,int *bufferPointer,int *lengthOfDomain)  
{   
	
	int valueWriting=0;
	while(buffer[*bufferPointer]!=0)  
	{        
		value[valueWriting] = buffer[*bufferPointer]; 
		valueWriting++;
		(*bufferPointer)++;
	}
	value[valueWriting] = 0;
	(*bufferPointer)++;
	*lengthOfDomain = valueWriting+1;

	
}

void encodeDomain(char* domain)           
{
	memset(value,0,MAX_SIZE_OF_DOMAIN);
	int valueWriting=0;
	char *p,*q;
	q = domain;
	p = q;
	char count = 0;
	while(1)   
	{
		if((*p=='.')||(*p==0))
		{
			*(value+valueWriting)=count;
			valueWriting += 1;
			memcpy(value+valueWriting,q,count);
			valueWriting += count; 
			
			count = 0;
			if (*p=='.')
			{
				q=p+1;
				p = q;
			}else break;
		}else
		{
			p++;
			count++;
		}
	}
}

void decodeDomain(char* domain)
{
	memset(value,0,MAX_SIZE_OF_DOMAIN);
	int valueWriting = 0;
	char *p = domain;  
	int count = *p;
	while(count!=0)
	{
		for(int i=0;i<count;i++)
		{
			p += 1;
			value[valueWriting] = *p;
			valueWriting++;
		}
		if (*(p+1)!=0) 
		{
			value[valueWriting] = '.';
			valueWriting++;
		}
		p += 1;
		count = *p;
	}
	value[valueWriting]=0;
}

void HZDomainTransform(wchar_t *res,char *domain)
{
	res = malloc(sizeof(MAX_SIZE_OF_DOMAIN));
	memset(res,0,MAX_SIZE_OF_DOMAIN);
	memcpy(res,domain,strlen(domain));	
}

unsigned short createTag(unsigned short qr,unsigned short opcode,unsigned short aa,unsigned short tc,unsigned short rd,unsigned short ra,unsigned short z,unsigned short rcode)
{
	unsigned short tag = 0;
	if (qr==1)  tag = tag | 0x8000;
	if (aa==1)  tag = tag | 0x0400;
	if (tc==1)  tag = tag | 0x0200;
	if (rd==1)  tag = tag | 0x0100;
	if (ra==1)  tag = tag | 0x0080;
	return tag;
}

unsigned short typeToNum(char* type)
{
	if (strcmp(type,"A")==0) return 0x0001;
	if (strcmp(type,"NS")==0) return 0x0002;
	if (strcmp(type,"CNAME")==0) return 0x0005;
	if (strcmp(type,"MX")==0) return 0x000F;
	return 0;
}
char* numToType(unsigned short num)
{
	if (num==0x0001) return "A";
	if (num==0x0002) return "NS";
	if (num==0x0005) return "CNAME";
	if (num==0x000F) return "MX";
	return "ERROR";
}

void create_query_header(struct DNS_Header *query_header,unsigned short id,unsigned short tag,unsigned short queryNum,unsigned short answerNum,unsigned short authorNum,unsigned short addNum)
{
	query_header->id = id;
	query_header->tag = tag;
	query_header->queryNum = queryNum;
	query_header->answerNum = answerNum;
	query_header->authorNum = authorNum;
	query_header->addNum = addNum;
}

void encode_header(struct DNS_Header *header,char *buffer,int *bufferPointer)
{
	put16bits(buffer,bufferPointer,header->id);
	put16bits(buffer,bufferPointer,header->tag);
	put16bits(buffer,bufferPointer,header->queryNum);
	put16bits(buffer,bufferPointer,header->answerNum);
	put16bits(buffer,bufferPointer,header->authorNum);
	put16bits(buffer,bufferPointer,header->addNum);
}
void decode_header(struct DNS_Header *header,char *buffer,int *bufferPointer)
{
	header->id=get16bits(buffer,bufferPointer);
	header->tag=get16bits(buffer,bufferPointer);
	header->queryNum=get16bits(buffer,bufferPointer);
	header->answerNum=get16bits(buffer,bufferPointer);
	header->authorNum=get16bits(buffer,bufferPointer);
	header->addNum=get16bits(buffer,bufferPointer);
}
void print_query_header(struct DNS_Header *query_header)
{
	printf("information of dns header:\n");
	printf("ID:%d\n",query_header->id);
	printf("TAG:0x%x\n",query_header->tag);
	printf("Query Number:%d\n",query_header->queryNum);
	printf("Answer Number:%d\n",query_header->answerNum);
	printf("Authority Number:%d\n",query_header->authorNum);
	printf("Additional Number:%d\n",query_header->addNum);
	printf("\n");
}

void create_query_section(struct DNS_Query *query_section,char* domain_name, unsigned short qtype, unsigned short qclass)
{
	int domain_length = strlen(domain_name);
	query_section->name = malloc(domain_length+1);
	memcpy(query_section->name,domain_name,domain_length+1);	
	
	query_section->qtype = qtype;
	query_section->qclass = qclass;	
}

void encode_query_section(struct DNS_Query *query_section,char *buffer,int *bufferPointer)
{

	char *domain_name;
	int lengthOfEncodedDomain = strlen(query_section->name)+2;
	domain_name = malloc(lengthOfEncodedDomain);
	encodeDomain(query_section->name);
	memcpy(domain_name,value,lengthOfEncodedDomain);
	putDomainName(buffer,bufferPointer,domain_name); 
	
	put16bits(buffer,bufferPointer,query_section->qtype);
	put16bits(buffer,bufferPointer,query_section->qclass);
}

void decode_query_section(struct DNS_Query *query_section,char *buffer,int *bufferPointer)
{
	char* domain_name = malloc(MAX_SIZE_OF_DOMAIN); 
	memset(domain_name,0,MAX_SIZE_OF_DOMAIN);
	int lengthOfDomain=0;
	getDomainName(buffer,bufferPointer,&lengthOfDomain);
	memcpy(domain_name,value,lengthOfDomain);
	
	decodeDomain(domain_name);
	memcpy(domain_name,value,strlen(domain_name));  
	
	query_section->name = domain_name;
	query_section->qtype = get16bits(buffer,bufferPointer);
	query_section->qclass = get16bits(buffer,bufferPointer);
}

void print_query_section(struct DNS_Query *query_section)
{
	printf("information of query section:\n");
	printf("Name:[%s]\n",query_section->name);
	printf("Type:[%s]\n",numToType(query_section->qtype));
	printf("Class:[IN]\n");
	printf("\n");
}

void create_resource_record(struct DNS_RR *resource_record,char* name, unsigned short type, unsigned short _class, unsigned int ttl, unsigned short pre,char *rdata) //data_len不用输入  
{
	int domain_length = strlen(name);
	resource_record->name = malloc(domain_length+1);   
	memcpy(resource_record->name,name,domain_length+1);
	
	resource_record->type = type;
	resource_record->_class = _class;
	resource_record->ttl = ttl;
	if (type==0x0001) resource_record->data_len=4;
		else resource_record->data_len = strlen(rdata) + 2;
	
	if (type==0x000F) {
		resource_record->pre = pre;
		resource_record->data_len += 2;
	}
	
	int rdata_length = strlen(rdata);
	resource_record->rdata = malloc(rdata_length+1);
	memcpy(resource_record->rdata,rdata,rdata_length+1);
}

void encode_resource_record(struct DNS_RR *resource_record,char *buffer,int *bufferPointer)
{
	char *domain_name;
	int lengthOfEncodedDomain = strlen(resource_record->name)+2;
	domain_name = malloc(lengthOfEncodedDomain);
	 
	encodeDomain(resource_record->name);
	memcpy(domain_name,value,lengthOfEncodedDomain);
	
	putDomainName(buffer,bufferPointer,domain_name); 
	
	put16bits(buffer,bufferPointer,resource_record->type);
	put16bits(buffer,bufferPointer,resource_record->_class);
	put32bits(buffer,bufferPointer,resource_record->ttl);
	put16bits(buffer,bufferPointer,resource_record->data_len);   
	if (resource_record->type==0x000F) 
		put16bits(buffer,bufferPointer,resource_record->pre);
		         
	if(resource_record->type == 0x0001)         
	{
		unsigned int rdata = inet_addr(resource_record->rdata);
		memcpy(buffer + *bufferPointer,&rdata,4);
		*bufferPointer += 4;
	
	}else{          
		char *rdata;
		int lengthOfEncodedDomain2 = strlen(resource_record->rdata)+2;
		rdata = malloc(lengthOfEncodedDomain2);
		encodeDomain(resource_record->rdata);
		memcpy(rdata,value,lengthOfEncodedDomain2);   
		putDomainName(buffer,bufferPointer,rdata); 
	}
}

void decode_resource_record(struct DNS_RR *resource_record,char *buffer,int *bufferPointer)
{
	char* domain_name = malloc(MAX_SIZE_OF_DOMAIN); 
	memset(domain_name,0,MAX_SIZE_OF_DOMAIN);
	int lengthOfDomain=0;
	getDomainName(buffer,bufferPointer,&lengthOfDomain);
	memcpy(domain_name,value,lengthOfDomain);
	decodeDomain(domain_name);
	memcpy(domain_name,value,strlen(domain_name));  
	resource_record->name = domain_name;
	
	resource_record->type = get16bits(buffer,bufferPointer);
	resource_record->_class = get16bits(buffer,bufferPointer);
	resource_record->ttl = get32bits(buffer,bufferPointer);   
	resource_record->data_len = get16bits(buffer,bufferPointer);
	if (resource_record->type==0x000F) 
			resource_record->pre = get16bits(buffer,bufferPointer);
	if(resource_record->type == 0x0001)   
	{
		unsigned int rdata;
		memcpy(&rdata,buffer + *bufferPointer,4);
		*bufferPointer += 4;
		
		struct in_addr in;
		memcpy(&in, &rdata, 4);  
		
		resource_record->rdata = malloc(MAX_SIZE_OF_DOMAIN);
		char *temp =  inet_ntoa(in);
		memcpy(resource_record->rdata,temp,strlen(temp)+1);
	}else{
		char* rdata = malloc(MAX_SIZE_OF_DOMAIN); 
		int lengthOfDomain2=0;
		getDomainName(buffer,bufferPointer,&lengthOfDomain2);
		memcpy(rdata,value,lengthOfDomain2);
		decodeDomain(rdata);
		memcpy(rdata,value,strlen(rdata));  
		resource_record->rdata = rdata;
	}
}

void print_resource_record(struct DNS_RR *resource_record)
{
	printf("information of dns rr\n");
	printf("name:[%s]\n",resource_record->name);
	printf("type:[%s]\n",numToType(resource_record->type));
	printf("class:[IN]\n");
	printf("ttl:%d\n",resource_record->ttl);
	printf("data length:%d\n",resource_record->data_len);
	if (resource_record->type==0x000F) 
		printf("prefix:0x%x\n",resource_record->pre);
	printf("ip/domain:[%s]\n",resource_record->rdata);
	printf("\n");
}

void cut(char** domainPointer)
{
	while(1)
	{
		(*domainPointer)++;
		if (**domainPointer=='.')
		{
			(*domainPointer)++;
			break;		
		}
		if (**domainPointer==0)
		{
			*domainPointer = NULL;
			break;
		}
	}
}

void addRRToCache(struct DNS_RR *resource_record, char* cacheFile)
{
	FILE *RR = fopen(cacheFile, "a+");
	fprintf(RR,"%s         ",resource_record->name);
	fprintf(RR,"%d         ",resource_record->ttl);
	fprintf(RR,"IN         ");
	fprintf(RR,"%s         ",numToType(resource_record->type));
	fprintf(RR,"%s\n",resource_record->rdata);
	fclose(RR);
}


//local server仅仅有中转功能，本身不带有RR记录。（但是由于支持cache，所以可以查cache）local server收到client请求的域名后，造包先发向root server，然后等待root server的回复。
//eg 假设查找bupt.edu.cn。发给root，root对应cn，会回复让local server去找edu.cn服务器的地址，然后edu.cn的服务器会让local server去找bupt.edu.cn。这就是迭代查询
//root server的地址是local server直接知道的（程序中）
//RR存于本地，通过文件读取查找到需要的行，并读入程序操作

//根据type的类型和DNS头部四个记录的值来判断是否已经得到所需的答案
//只有当autority记录数量为0,表示结束（只有NS记录会写在authority里。只要不含NS记录，则表示已得到最终答案）
int isEnd(struct DNS_Header *header)
{
	if (header->authorNum!=0)
		return 0;
	return 1;
}

int main(int argc, char *argv[]) 
{
	/*①设置监听多个端口，最大同时监听到一个TCP 一个UDP*/
	//服务端socket套接字文件描述符
	int serverSocket = socket(AF_INET, SOCK_STREAM, 0);
	//发送缓冲区和接收缓冲区
	char sendbuf[512];
	char recvbuf[512]; 
	int sendBufferPointer=0;
	int recvBufferPointer=0;
	//初始化buffer
	memset(sendbuf,0,512);
	memset(recvbuf,0,512);
		
	//声明两个套接字sockaddr_in结构体变量，分别表示客户端和服务器 
	struct sockaddr_in server_addr;  
	struct sockaddr_in clientAddr;  
	int addr_len = sizeof(clientAddr);  
	
	//欲与之建立连接的客户端的套接字描述符
	int client;  
	//初始化服务器端的套接字，
	bzero(&server_addr, sizeof(server_addr));  
	//用htons和htonl将端口和地址转成网络字节序  
	server_addr.sin_family = AF_INET;  
	server_addr.sin_port = htons(LOCAL_SERVER_PORT); 
	server_addr.sin_addr.s_addr = inet_addr(LOCAL_SERVER_IP);  
	
	//注意对于bind，accept之类的函数，里面套接字参数都是需要强制转换成(struct sockaddr *)  
	//绑定服务器IP 端口
	bind(serverSocket, (struct sockaddr *)&server_addr, sizeof(server_addr));
	//设置服务器上的socket为监听状态
	listen(serverSocket, 5);
	

	/*②循环等待连接，以免一次服务结束了之后服务器关闭。暂不考虑并发*/
	while(1)
	{
		//调用accept，进入阻塞状态，返回一个client套接字描述符
		client = accept(serverSocket, (struct sockaddr*)&clientAddr, (socklen_t*)&addr_len);
		
		//打印连接信息
		//这里要先获取生成clientAddr内容才能打印，目前只得到了client套接字描述符. getpeername函数用于获取与某个套接字关联的外地协议地址
		struct sockaddr_in c;
		socklen_t cLen = sizeof(c);
		getpeername(client, (struct sockaddr*) &c, &cLen); 
		
		//对于client的连接，先接收一个length，表示包的长度
		unsigned short recv_length;
		recv(client,&recv_length,2,0);
		recv_length = ntohs(recv_length);
		
		//接收客户端发来的数据，如果接收成功，recv返回值为接收字节数
		int dataNum = recv(client,recvbuf,recv_length,0);
					
		/*③提取recvbuf，构建DNS包*/
		//构造DNS包头部，从缓冲区读取一个DNS头部(query header)
		struct DNS_Header *client_query_header;
		client_query_header = malloc(sizeof(DH));
		decode_header(client_query_header,recvbuf,&recvBufferPointer);
		print_query_header(client_query_header);
		
		//构造准备发送的DNS头部
		struct DNS_Header *query_header;
		query_header = malloc(sizeof(DH));
		memcpy(query_header,client_query_header,sizeof(DH));
		query_header->queryNum = 1;
		
		/*④解析并处理请求 逻辑核心部分*/
		//处理，操作，调用不同的子程序，构建新的回复DNS PACKET，写入sendbuf 
		//根据queryNum得知有多少个请求  local负责将client发来的同一个包里的多个query分开解析组包，对每一个query做一次请求，返回一次结果
		for(int i=0;i<client_query_header->queryNum;i++)   
		{
			//读取解析一个请求部分
			struct DNS_Query *client_query_section;
			client_query_section = malloc(sizeof(DQ));
			decode_query_section(client_query_section,recvbuf,&recvBufferPointer);
			print_query_section(client_query_section);
			
			
			//************判断欲解析的域名是否已经在缓冲中存在记录***************
			int findInCache=0;
			FILE *RR = fopen( "localCache.txt", "a+" );
			//将文件读取指针指回头部
			fseek(RR,0,0);
			//定义一个RR结构体用来储存从文件中读入的一条RR
			struct DNS_RR *fileRR;
			fileRR = malloc(sizeof(DR));
			memset(fileRR,0,sizeof(DR));
			fileRR->name=malloc(MAX_SIZE_OF_DOMAIN);  
			fileRR->rdata=malloc(MAX_SIZE_OF_DOMAIN);
			
			while(fscanf(RR,"%s ",fileRR->name)!=EOF)   
			{
				fscanf(RR,"%d",&fileRR->ttl);
				char type[10],_class[10];
				fscanf(RR,"%s ",_class);
				fscanf(RR,"%s ",type);
				fileRR->type = typeToNum(type);
				fscanf(RR,"%s\n",fileRR->rdata);
				
				if((strcmp(client_query_section->name,fileRR->name)==0) && (client_query_section->qtype==fileRR->type))
				{
					//生成answer RR
					create_resource_record(fileRR,fileRR->name, fileRR->type, 0x0001, fileRR->ttl, 0x0000,fileRR->rdata);
					//生成头
					struct DNS_Header *header;
					header = malloc(sizeof(DH));
					unsigned short tag = createTag(1,0,1,0,0,0,0,0);
					if (strcmp(type,"MX")==0)   create_query_header(header,0x1235,tag,0,1,0,1);
						else create_query_header(header,0x1235,tag,0,1,0,0);
					//将头和answer encode进buffer
					encode_header(header,sendbuf,&sendBufferPointer);
					print_query_header(header);
					encode_resource_record(fileRR,sendbuf,&sendBufferPointer);
					print_resource_record(fileRR);
					findInCache = 1;
					break;
				}
			}
			
			//将文件读取指针指回头部
			fseek(RR,0,0);
			//如果找到了，且为MX类型，特殊，需要再搜索一遍，搜索到的邮件服务器域名的IP，并写入addition RR中发送    
			if ((fileRR->type==0x000F)&&(findInCache==1)) 
			{
				struct DNS_RR *addFileRR;
				addFileRR = malloc(sizeof(DR));
				addFileRR->name=malloc(MAX_SIZE_OF_DOMAIN);
				addFileRR->rdata=malloc(MAX_SIZE_OF_DOMAIN);
				while(fscanf(RR,"%s ",addFileRR->name)!=EOF)
				{
					fscanf(RR,"%d ",&addFileRR->ttl);
					char type[10],_class[10];
					fscanf(RR,"%s ",_class);
					fscanf(RR,"%s ",type);
					addFileRR->type = typeToNum(type);
					fscanf(RR,"%s\n",addFileRR->rdata);
					if(strcmp(fileRR->rdata,addFileRR->name)==0)
					{
						//生成addition RR
						create_resource_record(addFileRR,fileRR->rdata, 1, 1, fileRR->ttl, 0, addFileRR->rdata);
						encode_resource_record(addFileRR,sendbuf,&sendBufferPointer);
						print_resource_record(addFileRR);
						break;
					}
				}	
			}
			fclose(RR);
			//如果findInCache被置为1，说明已经在cache中找到要解析的域名，并且已经写入buffer，跳转到send处直接发送即可
			if (findInCache==1)
				goto findit;

			//**********没有执行goto语句，说明没有在缓存中直接找到,先向root发送请求**********
			//新建UDP 连接的buffer
			char UDPsendbuf[512];
			char UDPrecvbuf[512]; 
			int UDPsendBufferPointer=0;
			int UDPrecvBufferPointer=0;
			memset(UDPsendbuf,0,512);
			memset(UDPrecvbuf,0,512);
			
			//直接将从客户端接受收的client_query_header和client_query_section(即客户端发的整个DNS Packet)写入UDP发送缓冲区  
			encode_header(query_header,UDPsendbuf,&UDPsendBufferPointer);
			print_query_header(query_header);
			encode_query_section(client_query_section,UDPsendbuf,&UDPsendBufferPointer);
			print_query_section(client_query_section);
			
			//重要：定义用于接收的结构体头(recv_header)，authory,addition,answer   由于root服务器必然不可能返回最终结果，所以不开answer
			struct DNS_Header *recv_header;
			struct DNS_RR *recv_answer,*recv_authority,*recv_additional;
			recv_header = malloc(sizeof(DH));
			recv_authority = malloc(sizeof(DR));
			recv_additional = malloc(sizeof(DR));
			
			//与root建立UDP连接
			int sockfd=socket(AF_INET,SOCK_DGRAM,0);
			struct sockaddr_in addr;
			addr.sin_family =AF_INET;
			addr.sin_port =htons(ROOT_SERVER_PORT);
			addr.sin_addr.s_addr=inet_addr(ROOT_SERVER_IP);	
			
			bind(sockfd,(struct sockaddr*)&addr,sizeof(addr));
			
			//发送sendbuf（UDP无需发length）  
			sendto(sockfd,UDPsendbuf,UDPsendBufferPointer,0,(struct sockaddr*)&addr,sizeof(addr));
			
			//接收服务器发来的数据到recvbuf
			socklen_t len=sizeof(addr);
			recvfrom(sockfd,UDPrecvbuf,sizeof(UDPrecvbuf),0,(struct sockaddr*)&addr,&len);   
			
			//断开该次UDP连接
			close(sockfd); 
			
			//从recvbuffer解析并构造结构体root_header，以及anthority和additon并打印
			decode_header(recv_header,UDPrecvbuf,&UDPrecvBufferPointer);
			print_query_header(recv_header);
			 
			decode_resource_record(recv_authority,UDPrecvbuf,&UDPrecvBufferPointer);
			print_resource_record(recv_authority);
			decode_resource_record(recv_additional,UDPrecvbuf,&UDPrecvBufferPointer);
			print_resource_record(recv_additional);
			
			//重置UDPsendbuf UDPsendBufferPointer UDPrecvbuf UDPsendBufferPointer
			UDPsendBufferPointer=0;
			UDPrecvBufferPointer=0;
			memset(UDPsendbuf,0,512);
			memset(UDPrecvbuf,0,512);
			
			
			//用于计数本次循环是第几级服务器发来的
			int count=0;
			while(isEnd(recv_header)==0)  
			{
				count++;
				//向下一个服务器[IP]建立UDP连接
				int sockfm=socket(AF_INET,SOCK_DGRAM,0);
				struct sockaddr_in addr;
				addr.sin_family =AF_INET;
				addr.sin_port =htons(COMMON_SERVER_PORT);
				addr.sin_addr.s_addr=inet_addr(recv_additional->rdata);		
				//recv_additional->rdata即保存着下一个服务器的IP
				
				bind(sockfm,(struct sockaddr*)&addr,sizeof(addr));
				
				//重置UDPsendbuf UDPsendBufferPointer UDPrecvbuf UDPsendBufferPointer
				//释放recv_header,authory,addition,answer结构体
				UDPsendBufferPointer=0;
				UDPrecvBufferPointer=0;
				memset(UDPsendbuf,0,512);
				memset(UDPrecvbuf,0,512);
				free(recv_header);     recv_header = NULL;           
				free(recv_authority);  recv_authority = NULL;
				free(recv_additional); recv_additional = NULL;
				
				//直接将从客户端接受收的client_query_header和client_query_section写入UDP发送缓冲区
				encode_header(query_header,UDPsendbuf,&UDPsendBufferPointer);
				print_query_header(query_header);
				encode_query_section(client_query_section,UDPsendbuf,&UDPsendBufferPointer);
				print_query_section(client_query_section);
				
				//发送sendbuf
				sendto(sockfm,UDPsendbuf,UDPsendBufferPointer,0,(struct sockaddr*)&addr,sizeof(addr));
				
				//接受到recvbuf
				len=sizeof(addr);
				recvfrom(sockfm,UDPrecvbuf,sizeof(UDPrecvbuf),0,(struct sockaddr*)&addr,&len);
				
				//断开该次UDP连接
				close(sockfm); 
				
				//开始处理
				//从recvbuffer新建内存，解析并构造结构体root_header，以及anthority和additon并打印 
				//三种RR结构体都采用计数循环输出，避免判断MX or other  
				recv_header = malloc(sizeof(DH));
				recv_answer = malloc(sizeof(DR));
				recv_authority = malloc(sizeof(DR));
				recv_additional = malloc(sizeof(DR));
				
				decode_header(recv_header,UDPrecvbuf,&UDPrecvBufferPointer);
				print_query_header(recv_header);
				
				
				for(int j=0;j<recv_header->answerNum;j++){   //只可能循环0次或1次
					decode_resource_record(recv_answer,UDPrecvbuf,&UDPrecvBufferPointer);
					print_resource_record(recv_answer);
				}
				
				for(int j=0;j<recv_header->authorNum;j++){   //只可能循环0次或1次
					decode_resource_record(recv_authority,UDPrecvbuf,&UDPrecvBufferPointer);
					print_resource_record(recv_authority);
				}
				 
				for(int j=0;j<recv_header->addNum;j++){      //只可能循环0次或1次
					decode_resource_record(recv_additional,UDPrecvbuf,&UDPrecvBufferPointer);
					print_resource_record(recv_additional);
				}			
			}
			 
			
			//UDP请求的循环结束，此时构造得到的结构体已经得到该次query目标结果，且已经在循环中打印  
			//将从最终结果服务器返回来的结构体们分别写入sendbuf，准备发给客户端
			encode_header(recv_header,sendbuf,&sendBufferPointer);
			for(int j=0;j<recv_header->answerNum;j++){
				encode_resource_record(recv_answer,sendbuf,&sendBufferPointer);
				//将结果写入cache
				addRRToCache(recv_answer,"localCache.txt");
			}
			for(int j=0;j<recv_header->authorNum;j++){
				encode_resource_record(recv_authority,sendbuf,&sendBufferPointer);
				addRRToCache(recv_authority,"localCache.txt");
			}
			for(int j=0;j<recv_header->addNum;j++){
				encode_resource_record(recv_additional,sendbuf,&sendBufferPointer);
				addRRToCache(recv_additional,"localCache.txt");
			}
			
			
		findit:;
			/*⑤发送sendbuf，将所有query请求返回的最终结果（多个DNS PACKET）返还客户端*/
			//发送已准备好的在缓冲区的数据,包总长度即为当下发送缓冲区指针下标
			unsigned short send_length = htons(sendBufferPointer);
			//对于TCP（客户端-本地服务器），必须先发送一个DNS包总长度
			send(client,&send_length,2,0);
			send(client, sendbuf, sendBufferPointer, 0);   
			//一个querry的解析与回答发送结束,清空发送缓冲区与指针，准备进行下一次发送
			sendBufferPointer=0;
			memset(sendbuf,0,512);	
		}
		
		//对一个client的所有请求解析结束
		close(client);
		recvBufferPointer=0;
		memset(recvbuf,0,512);
	} 
}

	
	